import { BlockType, PageData, RenderBlock } from "../types";

export const parseContentToPages = (text: string): PageData[] => {
  const rawPages = text.split(/^---$/gm);
  
  return rawPages.map((pageText, index) => {
    const blocks: RenderBlock[] = [];
    const meta: PageData['meta'] = {};
    const lines = pageText.split('\n');
    
    lines.forEach((line) => {
      const trimmed = line.trim();
      
      if (!trimmed) {
        blocks.push({ type: BlockType.SPACER, content: '' });
        return;
      }

      // Check for Metadata syntax: @vol or @author
      const volMatch = trimmed.match(/^@vol\s+(.*)/i);
      const authorMatch = trimmed.match(/^@author\s+(.*)/i);

      // Check for Image syntax: 
      // 1. Markdown: ![alt](url)
      // 2. Naked URL: https://example.com/img.jpg
      const imageMatch = trimmed.match(/^!\[(.*?)\]\((.+)\)$/);
      const nakedUrlMatch = trimmed.match(/^(https?:\/\/[^\s]+)$/i);
      const coverMatch = trimmed.match(/^!cover\((.+)\)$/);

      if (volMatch) {
        meta.volume = volMatch[1];
      } else if (authorMatch) {
        meta.author = authorMatch[1];
      } else if (imageMatch) {
         blocks.push({ type: BlockType.IMAGE, content: imageMatch[2] }); // content is url
      } else if (nakedUrlMatch) {
         // Auto-detect raw URLs as images if they are on their own line
         blocks.push({ type: BlockType.IMAGE, content: nakedUrlMatch[1] });
      } else if (coverMatch) {
         blocks.push({ type: BlockType.IMAGE, content: coverMatch[1], meta: { isDropCap: false } }); // Treated as Cover Image
      } else if (trimmed.startsWith('# ')) {
        blocks.push({ type: BlockType.COVER_TITLE, content: trimmed.replace(/^# /, '') });
      } else if (trimmed.startsWith('## ')) {
        blocks.push({ type: BlockType.CHAPTER_TITLE, content: trimmed.replace(/^## /, '') });
      } else if (trimmed.startsWith('### ')) {
        blocks.push({ type: BlockType.SUBTITLE, content: trimmed.replace(/^### /, '') });
      } else if (trimmed.startsWith('> ')) {
        blocks.push({ type: BlockType.FULL_QUOTE, content: trimmed.replace(/^> /, '') });
      } else if (trimmed.startsWith('^')) {
        blocks.push({ 
          type: BlockType.PARAGRAPH, 
          content: trimmed.replace(/^\^/, ''), 
          meta: { isDropCap: true } 
        });
      } else if (trimmed.match(/^[-*]\s/)) {
         blocks.push({ type: BlockType.PARAGRAPH, content: trimmed, meta: { isList: true } });
      } else if (trimmed.match(/^\d+\.\s/)) {
         blocks.push({ type: BlockType.PARAGRAPH, content: trimmed, meta: { isList: true } });
      } else {
        blocks.push({ type: BlockType.PARAGRAPH, content: trimmed });
      }
    });
    
    return {
      id: `page-${index}-${Date.now()}`,
      blocks: blocks.filter(b => !(b.type === BlockType.SPACER && b.content === '')),
      meta
    };
  });
};

// Inline Token Types
type InlineType = 'text' | 'strong' | 'mark' | 'em' | 'link';

interface InlineNode {
  type: InlineType;
  text: string;
  href?: string;
}

export const parseInlineStyles = (text: string): InlineNode[] => {
  const nodes: InlineNode[] = [];
  const regex = /(==.*?==)|(\*\*.*?\*\*)|(\*.*?\*)|(\[.*?\]\(.*?\))/g;
  
  let lastIndex = 0;
  let match;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      nodes.push({ type: 'text', text: text.slice(lastIndex, match.index) });
    }

    const fullMatch = match[0];

    if (fullMatch.startsWith('==')) {
      nodes.push({ type: 'mark', text: fullMatch.slice(2, -2) });
    } else if (fullMatch.startsWith('**')) {
      nodes.push({ type: 'strong', text: fullMatch.slice(2, -2) });
    } else if (fullMatch.startsWith('*')) {
      nodes.push({ type: 'em', text: fullMatch.slice(1, -1) });
    } else if (fullMatch.startsWith('[')) {
      const linkMatch = fullMatch.match(/\[(.*?)\]\((.*?)\)/);
      if (linkMatch) {
        nodes.push({ type: 'link', text: linkMatch[1], href: linkMatch[2] });
      } else {
        nodes.push({ type: 'text', text: fullMatch });
      }
    }

    lastIndex = regex.lastIndex;
  }

  if (lastIndex < text.length) {
    nodes.push({ type: 'text', text: text.slice(lastIndex) });
  }

  return nodes;
};