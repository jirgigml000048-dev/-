import { GoogleGenAI } from "@google/genai";
import { MoodTheme } from "../types";

export const optimizeTextWithGemini = async (
  currentText: string,
  mood: MoodTheme
): Promise<string> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      console.warn("API Key not found in environment.");
      throw new Error("API Key missing");
    }

    const ai = new GoogleGenAI({ apiKey });
    
    const prompt = `
      You are an expert content editor for Xiaohongshu (Red Note).
      Please rewrite the following text to match a "${mood.name}" mood.
      
      Mood Characteristics:
      - ${mood.name}: ${mood.id === 'pure' ? 'Clean, minimalist, objective' : mood.id === 'warm' ? 'Cozy, healing, soft' : 'Emotional, poetic, deep'}.
      
      Formatting Rules (Strictly Maintain These):
      - Use '# ' for main title.
      - Use '## ' for chapter pages.
      - Use '### ' for subtitles.
      - Use '> ' for big impact quotes.
      - Use '>> ' for subtle inline quotes.
      - Use '^' at the start of a paragraph if it needs a drop cap (artistic start).
      - Use '---' to split pages.
      - Keep the structure similar but improve the wording to be more engaging and emotional.
      - Limit total length to be suitable for social media cards.
      - Output ONLY the raw text with formatting. No explanations.

      Input Text:
      ${currentText}
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || currentText;
  } catch (error) {
    console.error("Gemini optimization failed:", error);
    throw error;
  }
};