import React from 'react';
import { BlockType, MoodTheme, PageData, TextureType, RenderBlock } from '../types';
import { NOISE_BASE64 } from '../constants';
import { parseInlineStyles } from '../utils/parser';
import clsx from 'clsx';

interface PreviewCardProps {
  data: PageData;
  mood: MoodTheme;
  texture: TextureType;
  scale?: number;
  id?: string;
  pageIndex: number;
  totalPage: number;
  isSeamless?: boolean; // New prop for Long Image Export mode
}

// Helper to proxy images for CORS support
const getOptimizedImageUrl = (url: string) => {
  if (!url) return '';
  // If it's base64, return as is
  if (url.startsWith('data:')) return url;
  // If it's already using the proxy, return as is
  if (url.includes('wsrv.nl')) return url;
  
  // Use wsrv.nl as a CORS proxy. 
  // we serves the image with CORS headers which fixes the "tainted canvas" issue for export.
  return `https://wsrv.nl/?url=${encodeURIComponent(url)}&output=png`;
};

export const PreviewCard: React.FC<PreviewCardProps> = ({ 
  data, 
  mood, 
  texture, 
  scale = 1,
  id,
  pageIndex,
  totalPage,
  isSeamless = false
}) => {
  
  const WIDTH = 600;
  // CHANGED: Height 800px for 3:4 Aspect Ratio (600/800 = 0.75)
  const HEIGHT = 800; 
  
  const isDark = mood.bg.includes('#0') || mood.bg.includes('#1') || mood.bg === '#002FA7';
  const borderColor = isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.1)';
  const brandName = "请100位陌生女孩吃饭";
  
  // Cover Page Logic
  const isCoverPage = pageIndex === 0;
  const isLastPage = pageIndex === totalPage - 1;

  // Seamless Mode Logic:
  // - Show Header only on First Page
  // - Show Footer only on Last Page
  // - Remove fixed height and shadows
  const showHeader = !isSeamless || isCoverPage;
  const showFooter = !isSeamless || isLastPage;

  // Render Helper for Inline Styles (Bold, Mark, etc.)
  const renderInlineContent = (text: string) => {
    const inlineNodes = parseInlineStyles(text);
    return (
      <>
        {inlineNodes.map((node, i) => {
          if (node.type === 'strong') return <strong key={i} className="font-bold text-[1.05em]">{node.text}</strong>;
          if (node.type === 'em') return <em key={i} className="italic opacity-70 mx-0.5 font-serif">{node.text}</em>;
          if (node.type === 'mark') {
            return (
                <span 
                    key={i} 
                    className="font-bold mx-0.5 px-0.5"
                    style={{ 
                        // Premium Underline Style: Bottom 35% colored, transparent top
                        background: `linear-gradient(to bottom, transparent 65%, ${mood.accent} 65%)`,
                        color: 'inherit',
                        textDecoration: 'none'
                    }}
                >
                    {node.text}
                </span>
            );
          }
          if (node.type === 'link') return <span key={i} className="underline opacity-80 decoration-1 underline-offset-4 decoration-current">{node.text}</span>;
          return <span key={i}>{node.text}</span>;
        })}
      </>
    );
  };

  // Dynamic Padding Calculation for Seamless Mode
  const getPadding = () => {
      // Increased Base Horizontal Padding from 50px to 68px for a more premium look
      const px = "px-[68px]"; 

      // AGGRESSIVE COMPACT COVER PADDING: Reduced for 3:4 ratio to prevent overflow
      if (isCoverPage) return `${px} pt-[75px] pb-[35px]`; 
      
      if (!isSeamless) return `${px} pt-[100px] pb-[80px]`;
      
      // For Seamless Middle Pages: Remove vertical padding completely.
      const pt = "pt-0"; 
      const pb = isLastPage ? "pb-[80px]" : "pb-0";
      
      return `${px} ${pt} ${pb}`;
  };

  // Spacing Constants
  const SPACING_STANDARD = "mb-[24px]"; // Unified paragraph/block spacing
  const SPACING_SECTION_TOP = "mt-[56px]"; // Increased top margin for ## subtitles

  return (
    <div
      id={id}
      className="relative transition-colors duration-500 origin-top-left overflow-hidden"
      style={{
        width: `${WIDTH}px`,
        // In seamless mode, let content define height
        height: isSeamless ? 'auto' : `${HEIGHT}px`,
        minHeight: isSeamless ? '200px' : undefined,
        boxShadow: isSeamless ? 'none' : `
          0 25px 50px -12px rgba(0, 0, 0, 0.4),
          0 10px 30px -10px rgba(0, 10, 20, 0.3),
          0 5px 15px -5px rgba(0, 5, 15, 0.25)
        `,
        borderRadius: isSeamless ? '0px' : (isCoverPage ? '0px' : '12px'),
        backgroundColor: mood.bg,
        color: mood.text,
        transform: `scale(${scale})`,
        marginBottom: isSeamless ? '0px' : `${(HEIGHT * scale) - HEIGHT}px`,
        marginRight: isSeamless ? '0px' : `${(WIDTH * scale) - WIDTH}px`,
        transformOrigin: 'top left',
        // UNIFIED FONT: Enforcing Noto Serif SC for that premium editorial feel
        fontFamily: "'Noto Serif SC', serif", 
      }}
    >
      {/* Texture Overlay */}
      {texture === 'retro' && (
        <div 
          className="absolute inset-0 z-0 pointer-events-none mix-blend-overlay opacity-40 rounded-xl"
          style={{ backgroundImage: `url("${NOISE_BASE64}")` }}
        />
      )}

      {/* --- COVER PAGE MAGAZINE HEADER & LAYOUT --- */}
      {isCoverPage && (
        <>
            {/* Top Left Metadata - Moved UP aggressively */}
            <div className="absolute top-[28px] left-[68px] z-20 flex flex-col items-start gap-1">
                <div className="flex items-center gap-3">
                    <span className="text-[32px] italic leading-none" style={{color: mood.accent, fontFamily: "'Playfair Display', serif"}}>
                        {data.meta?.volume || 'Vol.24'}
                    </span>
                </div>
                <div className="h-[1px] w-[30px] bg-current opacity-30 my-0.5"></div>
                <span className="text-[10px] font-sans opacity-50 tracking-[0.2em] uppercase">
                    {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                </span>
            </div>

            {/* Right Side Vertical Anchor Brand - Moved up */}
            <div className="absolute top-[28px] right-[50px] bottom-[28px] z-20 flex flex-col items-center justify-between pointer-events-none">
                 <div className="writing-vertical-rl text-[11px] tracking-[0.4em] font-sans h-full flex justify-between opacity-60 border-r border-current pr-4 mr-2" style={{ borderColor: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.08)' }}>
                    <span className="font-semibold">{brandName}</span>
                    <span className="opacity-50 text-[9px] tracking-widest">RECORDING LIFE</span>
                </div>
            </div>
            
            {/* Bottom Left Watermark - Moved down */}
             <div className="absolute bottom-[28px] left-[68px] z-20 text-[11px] opacity-50 font-sans tracking-widest pointer-events-none flex gap-2 items-center">
                <span className="italic font-serif text-[13px] mr-1">by</span> {data.meta?.author || 'Gigi'}
             </div>
        </>
      )}


      {/* --- CONTENT PAGE HEADER --- */}
      {!isCoverPage && showHeader && (
        <div 
            className="absolute top-[45px] left-[68px] right-[68px] flex justify-between items-end pb-4 z-20"
            style={{ borderBottom: `1px solid ${borderColor}` }}
        >
            <span className="uppercase tracking-[0.2em] text-[9px] font-sans font-bold opacity-40">
                {brandName}
            </span>
            <span className="text-[12px] opacity-40 italic font-serif">
                Ch. {pageIndex}
            </span>
        </div>
      )}

      {/* --- MAIN CONTENT CONTAINER (Flow) --- */}
      <div className={clsx(
          "relative z-10 h-full w-full flex flex-col overflow-hidden text-left", // Enforced text-left
          getPadding()
      )}>
        
        <div className="flex-1 flex flex-col items-start"> 
          {data.blocks.map((block, idx) => {

            switch (block.type) {
              
              // === IMAGE BLOCK ===
              case BlockType.IMAGE:
                return (
                    <div key={idx} className={clsx(
                        "w-full relative overflow-hidden", 
                        // Tightened spacing for Cover: Reduced mb to 4, mt to 2
                        isCoverPage ? "mb-4 mt-2 shadow-xl" : `${SPACING_STANDARD} rounded-sm shadow-sm`
                    )}>
                        <img 
                            src={getOptimizedImageUrl(block.content)} 
                            alt="content" 
                            crossOrigin="anonymous"
                            className="w-full h-full object-cover"
                            style={{
                                filter: mood.id === 'obsidian' ? 'grayscale(20%)' : 'contrast(105%) saturate(90%)', // Subtle premium filter
                            }}
                        />
                        {/* Frame effect for cover images */}
                        {isCoverPage && (
                            <div className="absolute inset-0 border-[1px] border-white/20 pointer-events-none m-3"></div>
                        )}
                    </div>
                );

              // === MAIN TITLE (#) ===
              case BlockType.COVER_TITLE:
                return (
                  <h1 key={idx} 
                      className={clsx(
                          "font-bold leading-tight tracking-tight w-full",
                          // Increased mt-6 for more breathing room on Cover
                          isCoverPage ? "text-[42px] mb-3 mt-6" : `text-[42px] ${SPACING_STANDARD}`
                      )} 
                      style={{ color: isCoverPage ? mood.text : mood.accent }}>
                    {renderInlineContent(block.content)}
                  </h1>
                );

              // === SUBTITLE / CHAPTER TITLE (##) ===
              case BlockType.CHAPTER_TITLE:
                return (
                  <div key={idx} className={clsx(
                      "w-full", 
                      // Reduced margin for Cover: mt-1, mb-3
                      isCoverPage ? "mt-1 mb-3 opacity-90 border-l-2 border-current pl-4" : `${SPACING_SECTION_TOP} ${SPACING_STANDARD}`
                  )}>
                      <h2 
                        className={clsx("font-bold inline-block", isCoverPage ? "text-[24px] font-normal italic" : "text-[26px]")}
                        style={{ color: mood.text }}
                      >
                        {renderInlineContent(block.content)}
                      </h2>
                  </div>
                );

              // === DECORATIVE SUBTITLE / ENGLISH (###) ===
              case BlockType.SUBTITLE:
                if (isCoverPage) {
                    return (
                        // Reduced margins and font size: text-30px, mt-2, mb-4
                        <h3 key={idx} className="text-[30px] font-serif uppercase tracking-widest leading-none mt-2 mb-4 opacity-15" style={{ color: mood.text }}>
                            {renderInlineContent(block.content)}
                        </h3>
                    )
                }
                return (
                  <h3 key={idx} 
                      className={`font-bold mt-[24px] ${SPACING_STANDARD} flex items-center gap-3 text-[18px] tracking-wide`}
                      style={{ color: mood.accent }}>
                    <span className="w-4 h-[1px] bg-current opacity-70 block"></span>
                    {renderInlineContent(block.content)}
                  </h3>
                );

              // === QUOTES (>) ===
              case BlockType.FULL_QUOTE: 
                const isBigQuoteSymbol = block.content === "66" || block.content === '"';
                if (isBigQuoteSymbol) {
                    return <div key={idx} className="text-7xl font-serif opacity-10 text-left mt-6 mb-[-20px] leading-none ml-[-5px]">“</div>
                }

                // On Cover
                if (isCoverPage) {
                    return (
                        // Compact quote spacing
                        <div key={idx} className="w-full my-2 flex flex-col gap-2">
                             <blockquote className="text-[16px] italic leading-relaxed text-left opacity-90 pl-4 border-l border-current/30" style={{ color: mood.accent }}>
                                {renderInlineContent(block.content)}
                             </blockquote>
                        </div>
                    );
                }

                return (
                  <blockquote key={idx} 
                      className={`font-bold italic ${SPACING_STANDARD} text-left relative px-6 text-[20px] leading-[1.6] opacity-90 border-l-[3px]`}
                      style={{ 
                          color: mood.accent,
                          borderColor: mood.accent 
                      }}>
                    {renderInlineContent(block.content)}
                  </blockquote>
                );

              // === PARAGRAPH ===
              case BlockType.PARAGRAPH:
                const isList = block.meta?.isList;
                const isDropCap = block.meta?.isDropCap;
                
                return (
                  <div key={idx} 
                       className={clsx(
                           "tracking-wide text-left w-full", // Strictly Left
                           // Reduced margin for Cover
                           isCoverPage ? "text-[12px] opacity-60 font-sans mb-2 tracking-[0.05em]" : `text-[19px] leading-[1.85] ${SPACING_STANDARD}`, // Standardized Spacing
                           isList && "pl-[1.5em] -indent-[1.5em]"
                       )}
                       style={{ color: mood.text }}>
                    {isDropCap && !isCoverPage && (
                         <span className="float-left text-[64px] font-serif mr-4 mt-[-8px] leading-[0.8] opacity-100" style={{color: mood.accent}}>
                            {block.content.charAt(0)}
                         </span>
                    )}
                    {isDropCap && !isCoverPage ? renderInlineContent(block.content.slice(1)) : renderInlineContent(block.content)}
                  </div>
                );

              // === SPACER ===
              case BlockType.SPACER:
                return <div key={idx} className="h-[24px]" />;
                
              default:
                return null;
            }
          })}
        </div>

        {/* Separator for Long Image Export (Between Cover and Body) */}
        {isSeamless && isCoverPage && (
             <div className="w-full flex items-center justify-center mt-12 mb-8 opacity-30">
                <div className="h-px w-full border-t border-dashed border-current"></div>
             </div>
        )}

      </div>

      {/* --- CONTENT PAGE FOOTER --- */}
      {!isCoverPage && showFooter && (
        <>
            {!isSeamless && (
                <div className="absolute bottom-[40px] left-[68px] right-[68px] flex justify-between items-center z-20">
                    <div className="flex-1 text-center font-serif italic text-[14px] opacity-40">
                        {pageIndex}
                    </div>
                </div>
            )}
            
            <div className="absolute bottom-[20px] right-[60px] text-[9px] opacity-30 font-sans tracking-[0.2em] text-right uppercase">
                {brandName}
            </div>
        </>
      )}
    </div>
  );
};