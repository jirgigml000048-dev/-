
export type TextureType = 'clean' | 'retro';

export interface MoodTheme {
  id: string;
  name: string;
  bg: string;
  text: string;
  accent: string;
  secondary: string;
  font: string; // 'serif' | 'sans'
}

export enum BlockType {
  COVER_TITLE = 'COVER_TITLE',
  CHAPTER_TITLE = 'CHAPTER_TITLE',
  SUBTITLE = 'SUBTITLE',
  FULL_QUOTE = 'FULL_QUOTE',
  INLINE_QUOTE = 'INLINE_QUOTE',
  PARAGRAPH = 'PARAGRAPH',
  IMAGE = 'IMAGE',
  SPACER = 'SPACER',
}

export interface RenderBlock {
  type: BlockType;
  content: string;
  meta?: {
    isDropCap?: boolean;
    isBold?: boolean;
    isList?: boolean;
  };
}

export interface PageData {
  id: string;
  blocks: RenderBlock[];
  meta?: {
    volume?: string;
    author?: string;
  };
}
