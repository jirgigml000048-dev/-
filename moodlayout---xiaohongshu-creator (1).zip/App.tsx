import React, { useState, useRef, useEffect } from 'react';
import { Download, Sparkles, Layout, Palette, Image as ImageIcon, HelpCircle, ChevronRight, ChevronDown, Plus, FileImage } from 'lucide-react';
import * as htmlToImage from 'html-to-image';
import saveAs from 'file-saver';
import JSZip from 'jszip';

import { INITIAL_CONTENT, MOODS } from './constants';
import { parseContentToPages } from './utils/parser';
import { PreviewCard } from './components/PreviewCard';
import { TextureType, MoodTheme } from './types';
import { optimizeTextWithGemini } from './services/geminiService';

const SyntaxGuideItem = ({ symbol, desc, example }: { symbol: string, desc: string, example?: string }) => (
  <div className="flex items-start gap-3 text-xs mb-3 group">
    <code className="bg-white/10 text-purple-300 px-1.5 py-0.5 rounded font-mono shrink-0 border border-white/5">{symbol}</code>
    <div className="flex flex-col">
        <span className="text-gray-400 group-hover:text-gray-200 transition-colors">{desc}</span>
        {example && <span className="text-gray-600 italic mt-0.5 text-[10px]">{example}</span>}
    </div>
  </div>
);

const App = () => {
  const [content, setContent] = useState(INITIAL_CONTENT);
  const [mood, setMood] = useState<MoodTheme>(MOODS[0]); 
  const [texture, setTexture] = useState<TextureType>('clean');
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [showGuide, setShowGuide] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const longImageRef = useRef<HTMLDivElement>(null);
  
  const pages = React.useMemo(() => parseContentToPages(content), [content]);

  // Fix for "Failed to read cssRules" error with Google Fonts
  useEffect(() => {
    const loadFonts = async () => {
      const fontLinks = Array.from(document.querySelectorAll('link[rel="stylesheet"]'))
        .filter(link => (link as HTMLLinkElement).href.includes('fonts.googleapis.com'));
      
      for (const link of fontLinks) {
        try {
          // Fetch the CSS content manually
          const response = await fetch((link as HTMLLinkElement).href);
          const css = await response.text();
          
          // Create a local style tag with the content
          const style = document.createElement('style');
          style.innerHTML = css;
          document.head.appendChild(style);
          
          // Remove the external link to prevent html-to-image from choking on it
          link.remove();
        } catch (e) {
          console.warn("Failed to inline font:", e);
        }
      }
    };
    loadFonts();
  }, []);

  // Export Settings
  const EXPORT_OPTIONS = {
    pixelRatio: 2,
    filter: (node: HTMLElement) => {
        // Exclude script tags as they are not visual and can cause issues
        if (node.tagName === 'SCRIPT') return false;
        // Double safety: Exclude any remaining external font links
        if (node.tagName === 'LINK' && node.getAttribute('href')?.includes('fonts.googleapis.com')) return false;
        return true;
    },
    style: {
      transform: 'none',
      margin: '0',
      boxShadow: 'none',
    }
  };

  const handleExportZip = async () => {
    const zip = new JSZip();
    const folder = zip.folder("stories");
    if (!folder) return;
    setIsExporting(true);

    try {
        const promises = pages.map(async (page, index) => {
        const element = document.getElementById(page.id);
        if (element) {
            // @ts-ignore - Filter type definition mismatch in some versions, but valid
            const dataUrl = await htmlToImage.toPng(element, EXPORT_OPTIONS);
            const base64Data = dataUrl.replace(/^data:image\/png;base64,/, "");
            folder.file(`${index + 1}_${mood.id}.png`, base64Data, { base64: true });
        }
        });

        await Promise.all(promises);
        const contentBlob = await zip.generateAsync({ type: "blob" });
        saveAs(contentBlob, "xiaohongshu-posts.zip");
    } catch (err) {
        console.error("Export failed:", err);
        alert("Export failed. See console for details.");
    } finally {
        setIsExporting(false);
    }
  };

  const handleExportLongImage = async () => {
    if (!longImageRef.current) return;
    setIsExporting(true);

    try {
        // We capture the hidden container which is already laid out seamlessly
        // @ts-ignore
        const dataUrl = await htmlToImage.toPng(longImageRef.current, {
            ...EXPORT_OPTIONS,
            backgroundColor: mood.bg // Ensure background is filled
        });
        
        // Convert to blob and save
        const response = await fetch(dataUrl);
        const blob = await response.blob();
        saveAs(blob, "xiaohongshu-long-image.png");

    } catch (err) {
        console.error("Long Image Export failed:", err);
        alert("Export failed. See console for details.");
    } finally {
        setIsExporting(false);
    }
  };

  const handleAIPolish = async () => {
    setIsOptimizing(true);
    try {
      const polished = await optimizeTextWithGemini(content, mood);
      setContent(polished);
    } catch (e) {
      alert("Please check console for API Key errors.");
    } finally {
      setIsOptimizing(false);
    }
  };

  // Helper to insert text at cursor position
  const insertTextAtCursor = (textToInsert: string) => {
      const textarea = textareaRef.current;
      if (!textarea) {
          setContent(prev => prev + textToInsert);
          return;
      }

      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const text = textarea.value;
      
      const newText = text.substring(0, start) + textToInsert + text.substring(end);
      setContent(newText);

      // Restore cursor position after state update (setTimeout needed because React state update is async)
      setTimeout(() => {
          textarea.focus();
          textarea.setSelectionRange(start + textToInsert.length, start + textToInsert.length);
      }, 0);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64String = reader.result as string;
            // Ensure proper newline spacing
            const insertion = `\n![Image](${base64String})\n`;
            insertTextAtCursor(insertion);
        };
        reader.readAsDataURL(file);
    }
    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    const items = e.clipboardData.items;
    let hasImage = false;

    for (const item of items) {
        if (item.type.indexOf("image") !== -1) {
            e.preventDefault();
            hasImage = true;
            const blob = item.getAsFile();
            if (blob) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    const base64 = event.target?.result as string;
                    const insertion = `\n![Pasted Image](${base64})\n`;
                    insertTextAtCursor(insertion);
                };
                reader.readAsDataURL(blob);
            }
        }
    }
  };

  const triggerFileUpload = () => {
      fileInputRef.current?.click();
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#0a0a0c] text-white font-sans selection:bg-purple-500/30">
      
      {/* Hidden Container for Seamless Long Image Export */}
      <div className="fixed top-0 left-0 pointer-events-none opacity-0 -z-50 overflow-hidden" style={{ width: '600px' }}>
          <div ref={longImageRef} className="w-[600px] flex flex-col" style={{ backgroundColor: mood.bg }}>
              {pages.map((page, index) => (
                  <PreviewCard 
                    key={`${page.id}-export`}
                    data={page}
                    mood={mood}
                    texture={texture}
                    scale={1} // Actual size for export
                    pageIndex={index}
                    totalPage={pages.length}
                    isSeamless={true} // Enable seamless mode
                  />
              ))}
          </div>
      </div>

      {/* Hidden File Input */}
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleImageUpload} 
        accept="image/*" 
        className="hidden" 
      />

      {/* LEFT: Editor & Controls */}
      <div className="w-[420px] flex flex-col border-r border-white/10 bg-[#121214] shrink-0 z-20 shadow-2xl">
        
        {/* Header */}
        <div className="h-14 flex items-center px-5 border-b border-white/5 justify-between bg-[#121214]">
          <div className="flex items-center gap-2">
            <Layout className="w-4 h-4 text-purple-400" />
            <h1 className="font-bold tracking-wider text-xs text-gray-300">MOOD CREATOR</h1>
          </div>
          <button 
            onClick={handleAIPolish}
            disabled={isOptimizing}
            className="flex items-center gap-2 px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider bg-purple-500/10 text-purple-400 hover:bg-purple-500/20 rounded-md transition-all border border-purple-500/20"
          >
            <Sparkles className="w-3 h-3" />
            {isOptimizing ? 'Thinking...' : 'AI Enhance'}
          </button>
        </div>

        {/* Editor Area */}
        <div className="flex-1 relative">
          <textarea
            ref={textareaRef}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onPaste={handlePaste}
            className="w-full h-full bg-[#121214] p-6 resize-none focus:outline-none text-sm leading-7 text-gray-300 font-mono no-scrollbar"
            spellCheck={false}
            placeholder="Start writing or paste an image..."
          />
          {/* Quick Insert Actions */}
           <div className="absolute bottom-4 right-4 flex gap-2">
             <button onClick={triggerFileUpload} className="bg-white/10 hover:bg-white/20 p-2 rounded-full text-white/50 hover:text-white transition-all" title="Upload Local Image">
                <ImageIcon className="w-4 h-4" />
             </button>
           </div>
        </div>

        {/* Syntax Guide (Collapsible) */}
        <div className="border-t border-white/5 bg-[#0f0f11]">
            <button 
                onClick={() => setShowGuide(!showGuide)}
                className="w-full flex items-center justify-between px-6 py-3 text-xs font-medium text-gray-500 hover:text-gray-300 transition-colors"
            >
                <div className="flex items-center gap-2">
                    <HelpCircle className="w-3 h-3" />
                    <span>Guide</span>
                </div>
                {showGuide ? <ChevronDown className="w-3 h-3"/> : <ChevronRight className="w-3 h-3"/>}
            </button>
            
            {showGuide && (
                <div className="px-6 pb-4 max-h-[150px] overflow-y-auto no-scrollbar border-b border-white/5">
                    <SyntaxGuideItem symbol="@vol" desc="Set Volume No." example="@vol Vol.24" />
                    <SyntaxGuideItem symbol="@author" desc="Set Author" example="@author Name" />
                    <SyntaxGuideItem symbol="!cover(url)" desc="Cover Image" />
                    <SyntaxGuideItem symbol="![desc](url)" desc="Image" />
                    <SyntaxGuideItem symbol="# Text" desc="Giant Title" />
                    <SyntaxGuideItem symbol="## Text" desc="Subtitle" />
                    <SyntaxGuideItem symbol="---" desc="New Page" />
                </div>
            )}
        </div>

        {/* Controls Section */}
        <div className="h-[220px] bg-[#121214] p-6 flex flex-col gap-5 overflow-y-auto">
          
          {/* Mood Palette */}
          <div>
            <div className="flex items-center gap-2 mb-3 text-[10px] font-bold text-gray-500 uppercase tracking-widest">
              <Palette className="w-3 h-3" />
              Themes
            </div>
            <div className="grid grid-cols-8 gap-2">
              {MOODS.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setMood(m)}
                  className={`w-full aspect-square rounded-md border-2 transition-all relative group ${mood.id === m.id ? 'border-white scale-110 shadow-[0_0_10px_rgba(255,255,255,0.3)]' : 'border-transparent hover:scale-105 hover:border-white/20'}`}
                  style={{ backgroundColor: m.bg }}
                  title={m.name}
                >
                  <div className={`w-1.5 h-1.5 rounded-full absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 ${mood.id === m.id ? 'opacity-100 invert mix-blend-difference' : 'opacity-0'}`} style={{ backgroundColor: m.accent }} />
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-4">
             {/* Texture Toggle */}
            <div className="flex-1">
                <div className="flex items-center gap-2 mb-3 text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                    <ImageIcon className="w-3 h-3" />
                    Grain
                </div>
                <div className="flex bg-[#1e1e20] p-1 rounded-md border border-white/5">
                {(['clean', 'retro'] as TextureType[]).map((t) => (
                    <button
                    key={t}
                    onClick={() => setTexture(t)}
                    className={`flex-1 py-1.5 text-[10px] font-bold uppercase rounded text-center transition-all ${texture === t ? 'bg-white/10 text-white shadow-sm' : 'text-gray-500 hover:text-gray-300'}`}
                    >
                    {t}
                    </button>
                ))}
                </div>
            </div>

            {/* Export Buttons */}
            <div className="flex-1 flex flex-col gap-2">
                 <button
                    onClick={handleExportZip}
                    disabled={isExporting}
                    className="w-full bg-white hover:bg-gray-200 text-black py-2 rounded-md font-bold text-[10px] flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
                >
                    <Download className="w-3 h-3" />
                    {isExporting ? 'Exporting...' : 'Cards (ZIP)'}
                </button>
                <button
                    onClick={handleExportLongImage}
                    disabled={isExporting}
                    className="w-full bg-[#2c2c30] hover:bg-[#3d3d42] text-white py-2 rounded-md font-bold text-[10px] flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
                >
                    <FileImage className="w-3 h-3" />
                    {isExporting ? 'Exporting...' : 'Long Image'}
                </button>
            </div>
          </div>

        </div>
      </div>

      {/* RIGHT: Live Preview */}
      <div 
        className="flex-1 relative overflow-hidden flex flex-col items-center justify-center"
        style={{
          background: 'radial-gradient(circle at center, #2d2b35 0%, #151518 100%)',
        }}
      >
        <div className="absolute top-8 left-1/2 -translate-x-1/2 z-20 flex gap-4">
             <span className="text-[10px] font-mono text-white/20 bg-black/40 px-3 py-1 rounded border border-white/5 uppercase tracking-widest backdrop-blur-sm">
                Preview • {pages.length} Slides
             </span>
        </div>

        {/* Scrollable Canvas */}
        <div className="w-full h-full overflow-x-auto overflow-y-hidden flex items-center px-24 gap-16 snap-x snap-mandatory no-scrollbar pb-10 pt-10">
          {pages.map((page, index) => (
            <div key={page.id} className="snap-center shrink-0 flex flex-col items-center gap-4 group">
              <PreviewCard 
                id={page.id}
                data={page} 
                mood={mood} 
                texture={texture}
                scale={0.75}
                pageIndex={index}
                totalPage={pages.length}
                isSeamless={false} // Normal card mode
              />
              <span className="text-[10px] font-mono text-white/20 opacity-0 group-hover:opacity-100 transition-opacity">
                  {index === 0 ? "Cover" : `Slide ${index}`}
              </span>
            </div>
          ))}
          
           {/* Add Page Hint */}
           <div className="shrink-0 w-[80px] h-[500px] flex items-center justify-center border border-dashed border-white/5 rounded-full opacity-30 hover:opacity-60 transition-opacity cursor-pointer" onClick={() => {
               setContent(content + "\n\n---\n# New Page");
           }}>
             <div className="text-center text-white/30 text-xs font-mono rotate-90 whitespace-nowrap">
                Add New Slide +
             </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default App;