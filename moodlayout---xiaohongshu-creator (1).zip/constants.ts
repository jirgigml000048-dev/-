import { MoodTheme } from "./types";

// A noise texture base64 for the "Retro" effect
export const NOISE_BASE64 = `data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='0.4'/%3E%3C/svg%3E`;

export const MOODS: MoodTheme[] = [
  // Dark option for utility
  { id: 'truffle', name: 'Dark Truffle', bg: '#1E1B1E', text: '#FCE4EC', accent: '#F48FB1', secondary: '#2D2A2D', font: 'serif' },
  
  // Macaron Series
  { id: 'strawberry', name: 'Strawberry', bg: '#FFF0F5', text: '#880E4F', accent: '#FF4081', secondary: '#F8BBD0', font: 'serif' },
  { id: 'pistachio', name: 'Pistachio', bg: '#F1F8E9', text: '#33691E', accent: '#FF80AB', secondary: '#DCEDC8', font: 'sans' },
  { id: 'blueberry', name: 'Blueberry', bg: '#E3F2FD', text: '#1A237E', accent: '#FFAB91', secondary: '#BBDEFB', font: 'serif' },
  { id: 'lemon', name: 'Lemon Curd', bg: '#FFFDE7', text: '#5D4037', accent: '#26C6DA', secondary: '#FFF9C4', font: 'sans' },
  { id: 'lavender', name: 'Taro Milk', bg: '#F3E5F5', text: '#4A148C', accent: '#66BB6A', secondary: '#E1BEE7', font: 'serif' },
  { id: 'peach', name: 'White Peach', bg: '#FFF3E0', text: '#BF360C', accent: '#26A69A', secondary: '#FFE0B2', font: 'serif' },
  { id: 'mint', name: 'Mint Choco', bg: '#E0F2F1', text: '#4E342E', accent: '#00BCD4', secondary: '#B2DFDB', font: 'sans' },
];

export const ASPECT_RATIO = 0.6; // 600 / 1000

export const INITIAL_CONTENT = `@vol Vol.24
@author Gigi

# 极简主义,
## 诠释着极简与克制
Summer is forever.

!cover(https://images.unsplash.com/photo-1507643321288-61f2969960bd?w=800&auto=format&fit=crop&q=80)

### MINIMALISM

> 我们都很平凡
> 但我们在此
> 熠熠闪光

---
## 01. 留白的艺术

极简不仅仅是“少”，而是精准。
每一处留白，都是为了让真正重要的东西显露出来。

> 就像呼吸
> 需要空间

![Image](https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?w=800&auto=format&fit=crop&q=80)

在繁杂的信息洪流中，我们试图构建一座内心的孤岛。

---
## 02. 克制与自由

克制不是压抑，是更高级的自由。
当我们不再被物欲裹挟，灵魂才开始轻盈起舞。

^真正的极简，是对生命核心的回归。

我们终将在简单中，遇见最真实的自己。`;